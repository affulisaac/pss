import { USSDSimulator } from '@/components/ui/USSDSimulator';
export default function Home() {
  return <USSDSimulator />;
}