'use client';

export type SimulatedDevices = 'android' | 'ios' | 'web';