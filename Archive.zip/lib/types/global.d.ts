interface Window {
    makeUSSDRequest?: (request: any) => Promise<any>;
  }